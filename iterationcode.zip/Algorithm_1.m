clear
clc

disp ('Hi there, welcome to adsorption predictive model')
disp ('You need to enter values for: (a) effective grain size, (b) clean bed porosity')

grain_size = 'What is the effective grain size (mm)? ';
dc0 = input(grain_size);

clean_bed_porosity = 'What is the clean bed porosity (dimensionless)? ';
eta_0 = input(clean_bed_porosity);

l_m_raw = ((4*pi*dc0^3*10^-9)/(6*(1-eta_0)))^(1/3);
p1 = 10^(3-ceil(log10(l_m_raw)));
l_m_processed = round(l_m_raw*p1)/p1; 
A = ['Length of periodic cell = ',num2str(l_m_processed)]; 
disp (A);

R_c_raw = ((pi*dc0^2*10^-6)) / (6*l_m_processed^2);
p2 = 10^(3-ceil(log10(l_m_raw)));
R_c_processed = round(R_c_raw*p2)/p2; 
B = ['Constant dimensionless reaction rate = ',num2str(R_c_processed)]; 
disp (B);

disp ('We are now proceeding to function call with the clean bed porosity and dimensionelss reaction rate values')

[x_1, c, time_step, no_steps]= adsorption (eta_0,R_c_processed);


    for n = 1:1:no_steps

        time (1,1) = 0;
        time(1,n+1) = (n*time_step);
   
    end
    
k = x_1;

