function F = nonlinear_solver(x)

global a1
global a2
global cb_input
global t_R_input
global z_input
global dim_scgv
global total
global counter2

a = counter2;
   
    for m = 1:1:total

             fun = @(z) (((exp(log(cb_input).*z)) - (1+z.*(cb_input-1))) .* sin(m.*z.*pi));
             const7 (1,m) = integral(fun,0,1);
             const6 (1,m) = const7(1,m) - (((a2/a1)*(2/(m*pi))*(cos(m*pi)-1))/(((m)^2*pi^2)+(a2/a1))) - (((x(1)-(a2/a1))*(2/(m*pi))*(cos(m*pi)))/((((m)^2*pi^2)+(a2/a1)-x(1))))-((2/(m*pi))* ((a2/a1)*cb_input) * (cos(m*pi))/(((m)^2*pi^2)+(a2/a1)));

             b1 (1,m) = ((a2/a1)*(2/(m*pi))*(cos(m*pi)-1))/((((m)^2*pi^2)+(a2/a1)));
             b2 (1,m) = (((x(1)-(a2/a1))*(2/(m*pi))*(cos(m*pi)))*exp(-x(1)*t_R_input(a)))/((((m)^2*pi^2)+(a2/a1))-x(1));
             b3 (1,m) = ((a2/a1)*cb_input*(2/(m*pi))*(cos(m*pi)))/((((m)^2*pi^2)+(a2/a1)));
             b4 (1,m) = const6(1,m) * exp (-((((m)^2*pi^2)+(a2/a1)))*t_R_input(a));
             b5 (1,m) =  -(exp(-x(1)*t_R_input(a)))+(cb_input); 
             sum1  = ((((b1(1,m) + b2(1,m) + b3(1,m)+ b4(1,m))*cos(z_input*m*pi)))*(m*pi)) + b5(1,m);


    end

F(1) = sum1 - dim_scgv(1,a);

end





