function [ x_1,c, time_step, no_steps ] = adsorption( eta_0,R_c_processed )

global a1
global a2
global cb_input
global t_R_input
global z_input
global dim_scgv
global total
global counter
global counter2

a1 = eta_0;
a2 = R_c_processed;

disp ('You will now need to enter the values for the following: ')
disp ('(a) Background concentration of NOMs materials')
disp ('(b) Dimensionless time period for calibration')
disp ('(c) Dimensionless depth for calibration')
disp ('(d) Dimensionless concentration value from experiment')
disp ('(e) Dimensionless spatial concentration gradient value from experiment')

cb = ('What is the background concentration of NOMs materials? ');
cb_input = input(cb);
z = ('What is the dimensionless depth for calibration? ');
z_input = input(z);

num_data = ('What is the number of data points for calibration? ');
num = input(num_data);

for a = 1:1:num

t_R = ('What is the list of dimensionless time period for calibration? ');
t_R_input(1,a) = input(t_R);
disp (t_R_input)

end

for a = 1:1:num
dim_scg = ('What is the list of dimensionless spatial concentration gradient value from experiment? ');
dim_scgv(1,a) = input(dim_scg);
disp (dim_scgv)

end

% training step
no_cycles = ('What is the number of cycles? ');
total = input(no_cycles);
no_iterations = ('How many iterative loops do you want to attempt? ');
loops = input(no_iterations);

for counter2 = 1:1:num

        for count = 1:1:loops   
                calibration_s1 = @nonlinear_solver;
                x0 = 0;
                x(1,counter2) = fsolve(calibration_s1 ,x0);
        end
    
    xx(1,counter2) = x(1,counter2);
    disp (xx)
end


for counter2 = 1:1:num
      k_sum   = sum (xx);
end

x_1 = k_sum/(num-1);
disp (x_1)


% testing test
time = ('What is the total filtration period? ');
time_input = input(time);

t_step = ('What is the time-step for simulation? ');
time_step = input(t_step);

no_steps = time_input/time_step;

for n = 1:1:(no_steps+1)
     
    if n == 1     
        c(1,n)  = cb_input;
    
    else
        for counter = 1:1:total
        m = counter;
        
        fun = @(z) (((exp(log(cb_input).*z)) - (1+z.*(cb_input-1))) .* sin(m.*z.*pi));
        const7 (1,m) = integral(fun,0,1);
        
        const6 (1,m) = const7(1,m) - (((a2/a1)*(2/(m*pi))*(cos(m*pi)-1))/(((m)^2*pi^2)+(a2/a1))) - (((x(1)-(a2/a1))*(2/(m*pi))*(cos(m*pi)))/((((m)^2*pi^2)+(a2/a1)-x(1))))-((2/(m*pi))* ((a2/a1)*cb_input) * (cos(m*pi))/(((m)^2*pi^2)+(a2/a1)));
        b1 (1,m) = ((a2/a1)*(2/(m*pi))*(cos(m*pi)-1))/((((m)^2*pi^2)+(a2/a1)));
        b2 (1,m) = (((x_1-(a2/a1))*(2/(m*pi))*(cos(m*pi)))*exp(-x_1*(n-1)*time_step))/((((m)^2*pi^2)+(a2/a1))-x_1);
        b3 (1,m) = ((a2/a1)*cb_input*(2/(m*pi))*(cos(m*pi)))/((((m)^2*pi^2)+(a2/a1)));
        b4 (1,m) = const6(1,m) * exp (-((((m)^2*pi^2)+(a2/a1)))*(n-1)*time_step);
        b5 (1,m) = 1 - (z_input* exp(-x_1*(n-1)*time_step)) + (z_input*cb_input);        
        c(1,n)  = ((b1(1,m) + b2(1,m) + b3(1,m)+b4(1,m))*sin(z_input*m*pi)) + b5(1,m);
        end
    
    end
end
 
disp (c)  
end

